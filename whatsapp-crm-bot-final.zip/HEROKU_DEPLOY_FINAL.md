# 🚀 Guia Final de Deploy no Heroku - Bot WhatsApp CMA

## ✅ Status: PRONTO PARA DEPLOY

Todas as credenciais foram configuradas e o código está pronto para ser publicado!

---

## 📋 Passo 1: Criar App no Heroku

1. Acesse **https://dashboard.heroku.com**
2. Clique em **"New"** → **"Create new app"**
3. Dê um nome para o app (ex: `whatsapp-crm-bot-cma`)
4. Escolha a região **United States**
5. Clique em **"Create app"**

---

## 📦 Passo 2: Fazer Upload do Código

### Opção A: Via GitHub (Recomendado)

1. Acesse **https://github.com/new**
2. Crie um novo repositório chamado `whatsapp-crm-bot`
3. Clone o repositório para sua máquina
4. Copie os arquivos do projeto para lá
5. Faça push para o GitHub

No Heroku:
- Vá em **Deploy** → **Deployment method** → **GitHub**
- Conecte sua conta GitHub
- Selecione o repositório `whatsapp-crm-bot`
- Clique em **"Deploy Branch"**

### Opção B: Via Upload Direto

1. Baixe o arquivo `whatsapp-crm-bot-ready-deploy.zip`
2. Descompacte em uma pasta
3. Abra o terminal nessa pasta
4. Execute:
   ```bash
   heroku login
   heroku git:remote -a whatsapp-crm-bot-cma
   git push heroku master
   ```

---

## 🔧 Passo 3: Configurar Variáveis de Ambiente

No painel do Heroku:

1. Vá em **Settings**
2. Clique em **"Reveal Config Vars"**
3. Adicione as seguintes variáveis:

| Chave | Valor |
|-------|-------|
| `WHATSAPP_BUSINESS_ACCOUNT_ID` | `1301660565274054` |
| `WHATSAPP_PHONE_NUMBER_ID` | `557134326244` |
| `WHATSAPP_API_TOKEN` | `EAAVhkXx1bNEBRws4PazlnfG8GTv9WLZA1D8hwmxOLokN6qtBxsDnz6iL5lHTv4ITV3Pj7BXZAjn8C9dWxGmHX0lWeoxzVH50BjiKpr100NzQxHUm1DGRdgdKqkcCIr7mSKy5XmNEUO0qWxLbb3OBwGjidnUcqw5LzoG8HUDmpsfV2YEpZC3nYfHQZBdu4TzE17cphpp21Bjp3LFiqNXnIrYJiXOjSFUZAtD1ZCgdXL6aKHMPoyDvLlZCLd3umPN9gigsZBuMZB5feVXginBnDe8MgU2ZB1` |
| `WHATSAPP_WEBHOOK_VERIFY_TOKEN` | `whatsapp_webhook_token_cma_2026` |
| `CRM_API_BASE_URL` | `https://apimarcacao.priorizesenhas.com.br` |
| `CRM_SERIAL` | `0Pu5500l11` |
| `CRM_EMPRESA` | `CMA` |
| `NODE_ENV` | `production` |

---

## 🔗 Passo 4: Configurar Webhook no WhatsApp

Após o deploy, você terá uma URL como: `https://whatsapp-crm-bot-cma.herokuapp.com`

1. Acesse **https://developers.facebook.com**
2. Vá em seu app WhatsApp
3. Em **Configuration**, clique em **"Edit"**
4. Configure o Webhook:
   - **Callback URL**: `https://whatsapp-crm-bot-cma.herokuapp.com/webhook`
   - **Verify Token**: `whatsapp_webhook_token_cma_2026`
5. Clique em **"Verify and Save"**

---

## 📱 Passo 5: Testar o Bot

Envie uma mensagem para o número **+55 71 99620-0582** com:

```
Oi
```

O bot deve responder com um menu de opções! 🎉

---

## 🐛 Troubleshooting

### O bot não está respondendo

1. Verifique se o app está rodando no Heroku:
   - Vá em **Resources** → verifique se o dyno está ligado

2. Verifique os logs:
   - Vá em **More** → **View logs**
   - Procure por erros

3. Teste o webhook:
   - Acesse `https://whatsapp-crm-bot-cma.herokuapp.com/health`
   - Deve retornar `{"status": "ok"}`

### Erro de credenciais

- Verifique se as variáveis de ambiente estão corretas em **Settings** → **Config Vars**
- Certifique-se de que o API Token não expirou

### Erro de conexão com CRM

- Teste a API do CRM diretamente:
  ```bash
  curl -X POST "https://apimarcacao.priorizesenhas.com.br/Agendamento/AgendaListagens?serial=0Pu5500l11&empresa=CMA&tipo=3&id=0&id2=0"
  ```

---

## 📞 Suporte

Se tiver dúvidas, entre em contato! 

**URL do Bot**: https://whatsapp-crm-bot-cma.herokuapp.com
**Webhook**: https://whatsapp-crm-bot-cma.herokuapp.com/webhook
**Health Check**: https://whatsapp-crm-bot-cma.herokuapp.com/health

---

## 🎯 Próximos Passos

1. ✅ Deploy no Heroku
2. ✅ Configurar Webhook
3. ✅ Testar com clientes
4. 📊 Monitorar logs e performance
5. 🔄 Fazer ajustes conforme necessário

Boa sorte! 🚀
